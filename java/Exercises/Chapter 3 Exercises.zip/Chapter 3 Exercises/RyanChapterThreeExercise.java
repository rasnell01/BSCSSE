//Ryan Snell
//12 Feb 2024
//Chapter 3 Exercise

//imports
import java.util.*;

//new class
class RyanChapterThreeExercise{
	
	//new main
	public static void main(String[] args){
		
		Scanner keyboard = new Scanner(System.in);
		int taskNumber;
		int taskTimeDays;
		int realTimeDays;
		int numberOfRows;
		int slackTime = taskTime - realTime;
		for( int i = 0; i < numberOfRows; i++){
			
			String row = keyboard.nextLine();
			//split the row
			String[] numbers = row.split[];
			//parse int
			
			
			
			//2D array int[][] answers = new int[3][numbers]
			/*the print should look like this:
			task avail time actual time slack time
			1		5			3			2
			2		10			10			0
			3		7			6			1
			*/
		}//end for loop
		
	}//end main
	
}//end class