//imports

//new class
public class Patient {

    static int idNumber;
    static int age;

    public Patient(int idNumber, int age){

        this.idNumber = idNumber;
        this.age = age;

    }

}//end class
