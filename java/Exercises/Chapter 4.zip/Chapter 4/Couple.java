class Couple{

    public Person bride;
    public Person groom;

    public Couple(Person bride, Person groom){

        this.bride = bride;
        this.groom = groom;

    }//end method

}//end class