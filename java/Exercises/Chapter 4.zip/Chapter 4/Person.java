//imports

//new class
class Person{

    public String name;

    public Person(String name){

        this.name = name;

    }//end method
    
    @Override
    public String toString() {

        return " [" + name + "] ";

    }

    }//end class