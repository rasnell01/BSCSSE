//imports
import java.util.Scanner;

public class TestPatient {

    //test main
    public static void main(String[] args){

        Patient patientA = new Patient(1232, 34);
        Patient patientB = new Patient(8821, 65);
        Patient patientC = new Patient(23828, 23);

        System.out.println(patientA + " " + patientB + " " + patientC);

    }//end main

}//end class
