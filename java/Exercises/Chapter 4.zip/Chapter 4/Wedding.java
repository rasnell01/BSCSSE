//imports
import java.time.LocalDate;
class Wedding{

    public Couple aCouple;

    public Wedding(Couple aCouple){

        this.aCouple = aCouple;

    }//end method


}//end class