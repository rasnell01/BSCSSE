class Publication extends Book{
	
	String author;
	
}//end class