Class Publication{
	
	long callNumber;
	String title;
	double value;
	double depreciation;
	Loan loanPeriod();
	Loan fineRate();
	Loan reserveLoanPeriod();
	Loan reserveFineRate();
	Loan recallPeriod();
	
	
	private finding(title): Publication;{
		
		
		
	}//end method find
	
	private buying(){
		
		
	}//end method Buy
	
	private loaned(){
		
		
		
	}//end method Loan
	
	private borrowed(){
		
		
		
	}//end method Borrow
	
	private returned(){
		
		
		
	}//end method returnBy
	
	private reserved(){
		
		
		
	}//end method Reserve
	
	
	private unreserved(){
		
		
		
	}//end method Unreserve
	
	
	private DecreasedValue(){
		
		
		
	}//end method DecreaseValue
	
}//end class