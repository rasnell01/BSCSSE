class Article{
	
	String author;
	
}