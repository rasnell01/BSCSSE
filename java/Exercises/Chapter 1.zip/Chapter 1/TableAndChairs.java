//imports

//new class
class TableAndChairs {

    //new main
    public static void main(String[] args){

        System.out.println("x                      x");
        System.out.println("x                      x");
        System.out.println("x      xxxxxxxxxx      x");
        System.out.println("xxxxxx x        x xxxxxx");
        System.out.println("x    x x        x x    x");
        System.out.println("x    x x        x x    x");

    }//end main

}//end class

