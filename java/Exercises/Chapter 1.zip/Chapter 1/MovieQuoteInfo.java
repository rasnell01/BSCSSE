//imports

//new class
class MovieQuoteInfo {

    //new main
    public static void main(String[] args) {
        System.out.println("Favorite movie quote: 1,2,3,4,5? That's the kind of combination an idiot would have on his luggage!");
        System.out.println("Dark Helmet (Rick Moranis)");
        System.out.println("Spaceballs");
        System.out.println("1987");
    }//end main

}//end class