//Ryan A. Snell
//12 Feb 2024
//Chapter 2 Exercise

//imports
import java.util.*;

public class RyanWaterfallModel {

    public static void main(String[]args) {

        //String[] waterfallSteps = {"Requirement Analysis", "System Design", };
        ArrayList<String> waterfallSteps = new ArrayList<>();
        waterfallSteps.add("requirement analysis");
        waterfallSteps.add("system design");
        waterfallSteps.add("program design");
        waterfallSteps.add("coding");
        waterfallSteps.add("unit and integration testing");
        waterfallSteps.add("acceptance testing");
        waterfallSteps.add("operation and maintenance");


        ArrayList<String> tempList = waterfallSteps;
        Collections.shuffle(tempList);

        System.out.println("Here are the eight steps, please type them in, in the correct order seperated by a space.");
        for (int i = 0; i < tempList.size(); i++) {

            System.out.println(" " + tempList.get(i));


        }//end for loop

        Scanner keyboard = new Scanner(System.in);
        int chances = 0;
        int MAX_ATTEMPTS = 4;
        StringBuilder control = new StringBuilder();
        for (int i = 0; i < waterfallSteps.size(); i++) {

            control.append(" ");

        }//end for loop
        control.toString();

        String answer;
        while (chances < MAX_ATTEMPTS) {


            System.out.println("Please type your answers in the correct order," +
                    " with spaces in between the answers.");
            answer = keyboard.nextLine();
            answer.toString();

            //if the user replies correctly
            if (control.equals(answer) == true) {

                System.out.println("Congratulations! You have answered correctly!");
                break;

            } else {

                chances++;
                System.out.println("Sorry, that is not the correct order.");

            }//end if

        }//end while loop

    }//end main


}//end class