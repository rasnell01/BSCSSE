//Ryan Snell
//24 Feb 2024
//Chapter 5 Exercise
//imports
import java.util.*;

public class RyanPipeAndFilter {

    public static void main(String[] args){

        ArrayList<Character> letters = new ArrayList<Character>();
        System.out.println(changeToUpperCase(letters));
        System.out.println(advanceOneCharacter(letters));
        System.out.println(reverse(letters));

    }//end main

    private static char changeToUpperCase(ArrayList<Character> letters){

        char changeToUpperCase = 0;

        letters.add(changeToUpperCase);
        return changeToUpperCase;
    }//end method

    private static char advanceOneCharacter(ArrayList<Character> letters) {

        char advanceOneCharacter = 0;

        letters.add(advanceOneCharacter);
        return advanceOneCharacter;
    }//end method

    private static char reverse(ArrayList<Character> letters) {

        char reverse = 0;

        letters.add(reverse);
        return reverse;
    }//end method

}//end class
