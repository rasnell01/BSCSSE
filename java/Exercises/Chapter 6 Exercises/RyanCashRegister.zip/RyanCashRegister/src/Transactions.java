public class Transactions {

    TransactionMonitor.getMonitor();
    RegisterTape.getTape();

}//end class
