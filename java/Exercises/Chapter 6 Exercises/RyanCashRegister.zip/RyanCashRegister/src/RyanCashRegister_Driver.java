//Ryan Snell
//28 Feb 2024
//Chapter 6 Exercise
//imports

public class RyanCashRegister_Driver {

    public static void main(String[] args) {

        Controller.controller();

    }//end main

}//end class
