public class RegisterTape {

    private int tape;

    private int tape(int tape){

        int this.tape;

        return this.tape;
    }//end method
    public static int getTape{
        return tape;
    }//end getter
}//end class
