public class FinalCalculations {

    RegisterTape.getTape();

}//end class
