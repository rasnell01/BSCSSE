public class TransactionMonitor {

    RegisterTape.tape();
    private int monitor;

    private int monitor(){

        int this.monitor = 0;

        return this.monitor;
    }//end method

    public static int getMonitor{
        return monitor;
    }//end getter

}//end class
