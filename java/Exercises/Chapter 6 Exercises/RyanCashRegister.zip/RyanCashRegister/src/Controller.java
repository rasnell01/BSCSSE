public class Controller {

    private static void controller(){

        TransactionMonitor.getMonitor();
        RegisterTape.getTape();

    }//end method

}//end class
